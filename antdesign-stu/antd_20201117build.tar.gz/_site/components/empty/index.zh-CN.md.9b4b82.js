(window.webpackJsonp=window.webpackJsonp||[]).push([[75],{3071:function(t,n){t.exports={content:["section",["p","\u7A7A\u72B6\u6001\u65F6\u7684\u5C55\u793A\u5360\u4F4D\u56FE\u3002"],["h2","\u4F55\u65F6\u4F7F\u7528"],["ul",["li",["p","\u5F53\u76EE\u524D\u6CA1\u6709\u6570\u636E\u65F6\uFF0C\u7528\u4E8E\u663E\u5F0F\u7684\u7528\u6237\u63D0\u793A\u3002"]],["li",["p","\u521D\u59CB\u5316\u573A\u666F\u65F6\u7684\u5F15\u5BFC\u521B\u5EFA\u6D41\u7A0B\u3002"]]]],meta:{category:"Components",subtitle:"\u7A7A\u72B6\u6001",type:"\u6570\u636E\u5C55\u793A",title:"Empty",cols:1,cover:"https://gw.alipayobjects.com/zos/alicdn/MNbKfLBVb/Empty.svg",filename:"components/empty/index.zh-CN.md"},toc:["ul",["li",["a",{className:"bisheng-toc-h2",href:"#\u4F55\u65F6\u4F7F\u7528",title:"\u4F55\u65F6\u4F7F\u7528"},"\u4F55\u65F6\u4F7F\u7528"]],["li",["a",{className:"bisheng-toc-h2",href:"#API",title:"API"},"API"]],["li",["a",{className:"bisheng-toc-h2",href:"#\u5185\u7F6E\u56FE\u7247",title:"\u5185\u7F6E\u56FE\u7247"},"\u5185\u7F6E\u56FE\u7247"]]],api:["section",["h2","API"],["pre",{lang:"jsx",highlighted:`<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>Empty</span><span class="token punctuation">></span></span>
  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>Button</span><span class="token punctuation">></span></span>\u521B\u5EFA<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>Button</span><span class="token punctuation">></span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>Empty</span><span class="token punctuation">></span></span>`},["code",`<Empty>
  <Button>\u521B\u5EFA</Button>
</Empty>`]],["table",["thead",["tr",["th","\u53C2\u6570"],["th","\u8BF4\u660E"],["th","\u7C7B\u578B"],["th","\u9ED8\u8BA4\u503C"],["th","\u7248\u672C"]]],["tbody",["tr",["td","description"],["td","\u81EA\u5B9A\u4E49\u63CF\u8FF0\u5185\u5BB9"],["td","ReactNode"],["td","-"],["td"]],["tr",["td","image"],["td","\u8BBE\u7F6E\u663E\u793A\u56FE\u7247\uFF0C\u4E3A string \u65F6\u8868\u793A\u81EA\u5B9A\u4E49\u56FE\u7247\u5730\u5740\u3002"],["td","ReactNode"],["td",["code","Empty.PRESENTED_IMAGE_DEFAULT"]],["td"]],["tr",["td","imageStyle"],["td","\u56FE\u7247\u6837\u5F0F"],["td","CSSProperties"],["td","-"],["td"]]]],["h2","\u5185\u7F6E\u56FE\u7247"],["ul",["li",["p","Empty.PRESENTED_IMAGE_SIMPLE"],["div",{class:"site-empty-buildIn-img site-empty-buildIn-simple"},["div"]]],["li",["p","Empty.PRESENTED_IMAGE_DEFAULT"],["div",{class:"site-empty-buildIn-img site-empty-buildIn-default"}]]],["style",`
  .site-empty-buildIn-img {
    background-repeat: no-repeat;
    background-size: cover;
  }
  .site-empty-buildIn-simple {
    width: 55px;
    height: 35px;
    background-image: url("https://user-images.githubusercontent.com/507615/54591679-b0ceb580-4a65-11e9-925c-ad15b4eae93d.png");
  }
  .site-empty-buildIn-default {
    width: 121px;
    height: 116px;
    background-image: url("https://user-images.githubusercontent.com/507615/54591670-ac0a0180-4a65-11e9-846c-e55ffce0fe7b.png");
  }
  [data-theme="dark"] .site-empty-buildIn-simple {
    background-image: url("https://gw.alipayobjects.com/zos/antfincdn/ldFsHUh3Xh/ea62c5fe-07bb-4fcd-9d35-19220cef372e.png");
  }
  [data-theme="dark"] .site-empty-buildIn-default {
    background-image: url("https://gw.alipayobjects.com/mdn/rms_08e378/afts/img/A*gfq-SoT3wF0AAAAAAAAAAABkARQnAQ");
  }
`]]}}}]);
