(window.webpackJsonp=window.webpackJsonp||[]).push([[214],{3208:function(n,e){n.exports={content:["article",["p","\u672C\u6587\u6863\u5C06\u5E2E\u52A9\u4F60\u4ECE antd ",["code","3.x"]," \u7248\u672C\u5347\u7EA7\u5230 antd ",["code","4.x"]," \u7248\u672C\uFF0C\u5982\u679C\u4F60\u662F ",["code","2.x"]," \u6216\u8005\u66F4\u8001\u7684\u7248\u672C\uFF0C\u8BF7\u5148\u53C2\u8003\u4E4B\u524D\u7684",["a",{title:null,href:"https://github.com/ant-design/ant-design/blob/2adf8ced24da7b3cb46a3475854a83d76a98c536/CHANGELOG.zh-CN.md#300"},"\u5347\u7EA7\u6587\u6863"],"\u5347\u7EA7\u5230 3.x\u3002"],["h2","\u5347\u7EA7\u51C6\u5907"],["ol",["li",["p","\u8BF7\u5148\u5347\u7EA7\u5230 3.x \u7684\u6700\u65B0\u7248\u672C\uFF0C\u6309\u7167\u63A7\u5236\u53F0 warning \u4FE1\u606F\u79FB\u9664/\u4FEE\u6539\u76F8\u5173\u7684 API\u3002"]],["li",["p","\u5347\u7EA7\u9879\u76EE React 16.12.0 \u4EE5\u4E0A\u3002"],["ul",["li",["p","\u5982\u679C\u4F60\u4ECD\u5728\u4F7F\u7528 React 15\uFF0C\u8BF7\u53C2\u8003 ",["a",{title:null,href:"https://reactjs.org/blog/2017/09/26/react-v16.0.html#breaking-changes"},"React 16 \u5347\u7EA7\u6587\u6863"],"\u3002"]],["li",["p","\u5176\u4F59 React 16 \u5E9F\u5F03\u751F\u547D\u5468\u671F API \u8BF7\u53C2\u8003 ",["a",{title:null,href:"https://reactjs.org/blog/2018/03/27/update-on-async-rendering.html#gradual-migration-path"},"\u8FC1\u79FB\u5BFC\u5F15"],"\u3002"]]]]],["h2","4.0 \u6709\u54EA\u4E9B\u4E0D\u517C\u5BB9\u7684\u53D8\u5316"],["h3","\u8BBE\u8BA1\u89C4\u8303\u8C03\u6574"],["ul",["li",["p","\u884C\u9AD8\u4ECE ",["code","1.5"],"(",["code","21px"],") \u8C03\u6574\u4E3A ",["code","1.5715"],"(",["code","22px"],")\u3002"]],["li",["p","\u57FA\u7840\u5706\u89D2\u8C03\u6574\uFF0C\u7531 ",["code","4px"]," \u6539\u4E3A ",["code","2px"],"\u3002"]],["li",["p","Selected \u989C\u8272\u548C Hovered \u989C\u8272\u8FDB\u884C\u4E86\u4EA4\u6362\u3002"]],["li",["p","\u5168\u5C40\u9634\u5F71\u4F18\u5316\uFF0C\u8C03\u6574\u4E3A\u4E09\u5C42\u9634\u5F71\u533A\u5206\u63A7\u4EF6\u5C42\u6B21\u5173\u7CFB\u3002"]],["li",["p","\u6C14\u6CE1\u786E\u8BA4\u6846\u4E2D\u56FE\u6807\u7684\u4F7F\u7528\u6539\u53D8\uFF0C\u7531\u95EE\u53F7\u6539\u4E3A\u611F\u53F9\u53F7\u3002"]],["li",["p","\u90E8\u5206\u7EC4\u4EF6\u9009\u4E2D\u989C\u8272\u7EDF\u4E00\u6539\u4E3A ",["code","@blue-1: #E6F7FF"],"\uFF0C\u5BF9\u5E94 ",["code","hover"]," \u989C\u8272\u6539\u4E3A ",["code","@gray-2: #FAFAFA"],"\u3002"]],["li",["p","\u62A5\u9519\u8272\u8272\u503C\u8C03\u6574\uFF0C\u7531 ",["code","@red-5: #F5222D"]," \u6539\u4E3A ",["code","@red-5: #FF4D4F"],"\u3002"]],["li",["p","\u5206\u5272\u7EBF\u989C\u8272\u660E\u5EA6\u964D\u4F4E\uFF0C\u7531 ",["code","#E8E8E8"]," \u6539\u4E3A ",["code","#F0F0F0"],"\u3002"]],["li",["p","DatePicker \u4EA4\u4E92\u91CD\u505A\uFF0C\u9762\u677F\u548C\u8F93\u5165\u6846\u5206\u79BB\uFF0C\u8303\u56F4\u9009\u62E9\u73B0\u53EF\u5355\u72EC\u9009\u62E9\u5F00\u59CB\u548C\u7ED3\u675F\u65F6\u95F4\u3002"]],["li",["p","Table \u9ED8\u8BA4\u80CC\u666F\u989C\u8272\u4ECE\u900F\u660E\u4FEE\u6539\u4E3A\u767D\u8272\u3002"]],["li",["p","Tabs \u706B\u67F4\u68CD\u6837\u5F0F\u7F29\u77ED\u4E3A\u548C\u6587\u5B57\u7B49\u957F\u3002"]],["li",["p","Tabs \u4EA4\u4E92\u91CD\u505A\uFF0CDOM \u7ED3\u6784\u6539\u53D8\u3002",["code","4.3.0"]]]],["h3","\u517C\u5BB9\u6027\u8C03\u6574"],["ul",["li",["p","IE \u6700\u4F4E\u652F\u6301\u7248\u672C\u4E3A IE 11\u3002"]],["li",["p","React \u6700\u4F4E\u652F\u6301\u7248\u672C\u4E3A React 16.9\uFF0C\u90E8\u5206\u7EC4\u4EF6\u5F00\u59CB\u4F7F\u7528 hooks \u8FDB\u884C\u91CD\u6784\u3002"],["ul",["li",["p","\u91CD\u6784\u901A\u8FC7 ",["code","useMemo"]," \u8FDB\u884C\u6027\u80FD\u4F18\u5316\uFF0C\u8BF7\u52FF\u4F7F\u7528 mutable data \u4F5C\u4E3A\u53C2\u6570\u3002"]]]]],["h4","\u79FB\u9664\u5E9F\u5F03\u7684 API"],["ul",["li",["p","\u79FB\u9664\u4E86 LocaleProvider\uFF0C\u8BF7\u4F7F\u7528 ",["code","ConfigProvider"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Mention\uFF0C\u8BF7\u4F7F\u7528 ",["code","Mentions"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Alert \u7684 ",["code","iconType"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","icon"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Modal.xxx \u7684 ",["code","iconType"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","icon"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Form.create \u65B9\u6CD5\uFF0C",["code","form"]," \u73B0\u53EF\u7531 ",["code","Form.useForm"]," \u83B7\u53D6\u3002"]],["li",["p","\u79FB\u9664\u4E86 Form.Item \u7684 ",["code","id"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","htmlFor"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Typography \u7684 ",["code","setContentRef"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","ref"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 TimePicker \u7684 ",["code","allowEmpty"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","allowClear"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Tag \u7684 ",["code","afterClose"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","onClose"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Card \u7684 ",["code","noHovering"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","hoverable"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Carousel \u7684 ",["code","vertical"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","dotPosition"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Drawer \u7684 ",["code","wrapClassName"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","className"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 TextArea \u7684 ",["code","autosize"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","autoSize"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Affix \u7684 ",["code","offset"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","offsetTop"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Transfer \u7684 ",["code","onSearchChange"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","onSearch"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Transfer \u7684 ",["code","body"]," \u5C5E\u6027\uFF0C\u8BF7\u4F7F\u7528 ",["code","children"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Transfer \u7684 ",["code","lazy"]," \u5C5E\u6027\uFF0C\u5B83\u5E76\u6CA1\u6709\u8D77\u5230\u771F\u6B63\u7684\u4F18\u5316\u6548\u679C\u3002"]],["li",["p","\u79FB\u9664\u4E86 Select \u7684 ",["code","combobox"]," \u6A21\u5F0F\uFF0C\u8BF7\u4F7F\u7528 ",["code","AutoComplete"]," \u66FF\u4EE3\u3002"]],["li",["p","\u79FB\u9664\u4E86 Table \u7684 ",["code","rowSelection.hideDefaultSelections"]," \u5C5E\u6027\uFF0C\u8BF7\u5728 ",["code","rowSelection.selections"]," \u4E2D\u4F7F\u7528 ",["code","SELECTION_ALL"]," \u548C ",["code","SELECTION_INVERT"]," \u66FF\u4EE3\uFF0C",["a",{title:null,href:"/components/table/#components-table-demo-row-selection-custom"},"\u81EA\u5B9A\u4E49\u9009\u62E9\u9879"],"\u3002"]],["li",["p","\u5E9F\u5F03 Button.Group\uFF0C\u8BF7\u4F7F\u7528 ",["code","Space"]," \u4EE3\u66FF\u3002"]]],["h4","\u56FE\u6807\u5347\u7EA7"],["p","\u5728 ",["code","antd@3.9.0"]," \u4E2D\uFF0C\u6211\u4EEC\u5F15\u5165\u4E86 svg \u56FE\u6807\uFF08",["a",{title:null,href:"https://github.com/ant-design/ant-design/issues/10353"},"\u4E3A\u4F55\u4F7F\u7528 svg \u56FE\u6807\uFF1F"],"\uFF09\u3002\u4F7F\u7528\u4E86\u5B57\u7B26\u4E32\u547D\u540D\u7684\u56FE\u6807 API \u65E0\u6CD5\u505A\u5230\u6309\u9700\u52A0\u8F7D\uFF0C\u56E0\u800C\u5168\u91CF\u5F15\u5165\u4E86 svg \u56FE\u6807\u6587\u4EF6\uFF0C\u8FD9\u5927\u5927\u589E\u52A0\u4E86\u6253\u5305\u4EA7\u7269\u7684\u5C3A\u5BF8\u3002\u5728 4.0 \u4E2D\uFF0C\u6211\u4EEC\u8C03\u6574\u4E86\u56FE\u6807\u7684\u4F7F\u7528 API \u4ECE\u800C\u652F\u6301 tree shaking\uFF0C\u51CF\u5C11 antd \u9ED8\u8BA4\u5305\u4F53\u79EF\u7EA6 150 KB(Gzipped)\u3002"],["p","\u65E7\u7248 Icon \u4F7F\u7528\u65B9\u5F0F\u5C06\u88AB\u5E9F\u5F03\uFF1A"],["pre",{lang:"jsx",highlighted:`<span class="token keyword">import</span> <span class="token punctuation">{</span> Icon<span class="token punctuation">,</span> Button <span class="token punctuation">}</span> <span class="token keyword">from</span> <span class="token string">'antd'</span><span class="token punctuation">;</span>

<span class="token keyword">const</span> Demo <span class="token operator">=</span> <span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token operator">=</span><span class="token operator">></span> <span class="token punctuation">(</span>
  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>Icon</span> <span class="token attr-name">type</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>smile<span class="token punctuation">"</span></span> <span class="token punctuation">/></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>Button</span> <span class="token attr-name">icon</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>smile<span class="token punctuation">"</span></span> <span class="token punctuation">/></span></span>
  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">></span></span>
<span class="token punctuation">)</span><span class="token punctuation">;</span>`},["code",`import { Icon, Button } from 'antd';

const Demo = () => (
  <div>
    <Icon type="smile" />
    <Button icon="smile" />
  </div>
);`]],["p","4.0 \u4E2D\u4F1A\u91C7\u7528\u6309\u9700\u5F15\u5165\u7684\u65B9\u5F0F\uFF1A"],["pre",{lang:"diff",highlighted:`  import { Button } from 'antd';

  // tree-shaking supported
<span class="token deleted">- import { Icon } from 'antd';</span>
<span class="token inserted">+ import { SmileOutlined } from '@ant-design/icons';</span>

  const Demo = () => (
    &lt;div>
<span class="token deleted">-     &lt;Icon type="smile" /></span>
<span class="token inserted">+     &lt;SmileOutlined /></span>
      &lt;Button icon={&lt;SmileOutlined />} />
    &lt;/div>
  );

  // or directly import
  import SmileOutlined from '@ant-design/icons/SmileOutlined';`},["code",`  import { Button } from 'antd';

  // tree-shaking supported
- import { Icon } from 'antd';
+ import { SmileOutlined } from '@ant-design/icons';

  const Demo = () => (
    <div>
-     <Icon type="smile" />
+     <SmileOutlined />
      <Button icon={<SmileOutlined />} />
    </div>
  );

  // or directly import
  import SmileOutlined from '@ant-design/icons/SmileOutlined';`]],["p","\u4F60\u5C06\u4ECD\u7136\u53EF\u4EE5\u901A\u8FC7\u517C\u5BB9\u5305\u7EE7\u7EED\u4F7F\u7528\uFF1A"],["pre",{lang:"jsx",highlighted:`<span class="token keyword">import</span> <span class="token punctuation">{</span> Button <span class="token punctuation">}</span> <span class="token keyword">from</span> <span class="token string">'antd'</span><span class="token punctuation">;</span>
<span class="token keyword">import</span> <span class="token punctuation">{</span> Icon <span class="token punctuation">}</span> <span class="token keyword">from</span> <span class="token string">'@ant-design/compatible'</span><span class="token punctuation">;</span>

<span class="token keyword">const</span> Demo <span class="token operator">=</span> <span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token operator">=</span><span class="token operator">></span> <span class="token punctuation">(</span>
  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span><span class="token punctuation">></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>Icon</span> <span class="token attr-name">type</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>smile<span class="token punctuation">"</span></span> <span class="token punctuation">/></span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>Button</span> <span class="token attr-name">icon</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>smile<span class="token punctuation">"</span></span> <span class="token punctuation">/></span></span>
  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">></span></span>
<span class="token punctuation">)</span><span class="token punctuation">;</span>`},["code",`import { Button } from 'antd';
import { Icon } from '@ant-design/compatible';

const Demo = () => (
  <div>
    <Icon type="smile" />
    <Button icon="smile" />
  </div>
);`]],["h4","\u7EC4\u4EF6\u91CD\u6784"],["ul",["li",["p","Form \u91CD\u5199"],["ul",["li",["p","\u4E0D\u518D\u9700\u8981 ",["code","Form.create"],"\u3002"]],["li",["p","\u5D4C\u5957\u5B57\u6BB5\u652F\u6301\u4ECE ",["code","'xxx.yyy'"]," \u6539\u6210 ",["code","['xxx', 'yyy']"],"\u3002"]],["li",["p","\u8FC1\u79FB\u6587\u6863\u8BF7\u67E5\u770B",["a",{title:null,href:"/components/form/v3"},"\u6B64\u5904"],"\u3002"]]]],["li",["p","DatePicker \u91CD\u5199"],["ul",["li",["p","\u63D0\u4F9B ",["code","picker"]," \u5C5E\u6027\u7528\u4E8E\u9009\u62E9\u5668\u5207\u6362\u3002"]],["li",["p","\u8303\u56F4\u9009\u62E9\u73B0\u5728\u53EF\u4EE5\u5355\u72EC\u9009\u62E9\u5F00\u59CB\u548C\u7ED3\u675F\u65F6\u95F4\u3002"]],["li",["p",["code","onPanelChange"]," \u5728\u9762\u677F\u503C\u53D8\u5316\u65F6\u4E5F\u4F1A\u89E6\u53D1\u3002"]],["li",["p",["a",{title:null,href:"/components/date-picker-cn/#components-date-picker-demo-date-render"},"\u81EA\u5B9A\u4E49\u5355\u5143\u683C\u6837\u5F0F"],"\u7684\u7C7B\u540D\u4ECE ",["code","ant-calendar-date"]," \u6539\u4E3A ",["code","ant-picker-cell-inner"],"\u3002"]]]],["li",["p","Tree\u3001Select\u3001TreeSelect\u3001AutoComplete \u91CD\u65B0\u5199"],["ul",["li",["p","\u4F7F\u7528\u865A\u62DF\u6EDA\u52A8\u3002"]],["li",["p",["code","onBlur"]," \u65F6\u4E0D\u518D\u4FEE\u6539\u9009\u4E2D\u503C\uFF0C\u4E14\u8FD4\u56DE React \u539F\u751F\u7684 ",["code","event"]," \u5BF9\u8C61\u3002"]],["li",["p","AutoComplete \u4E0D\u518D\u652F\u6301 ",["code","optionLabelProp"],"\uFF0C\u8BF7\u76F4\u63A5\u8BBE\u7F6E Option ",["code","value"]," \u5C5E\u6027\u3002"]],["li",["p","AutoComplete \u9009\u9879\u4E0E Select \u5BF9\u9F50\uFF0C\u8BF7\u4F7F\u7528 ",["code","options"]," \u4EE3\u66FF ",["code","dataSource"],"\u3002"]],["li",["p","Select \u79FB\u9664 ",["code","dropdownMenuStyle"]," \u5C5E\u6027\u3002"]],["li",["p","\u5982\u679C\u4F60\u9700\u8981\u8BBE\u7F6E\u5F39\u7A97\u9AD8\u5EA6\u8BF7\u4F7F\u7528 ",["code","listHeight"]," \u6765\u4EE3\u66FF ",["code","dropdownStyle"]," \u7684\u9AD8\u5EA6\u6837\u5F0F\u3002"]],["li",["p",["code","filterOption"]," \u7B2C\u4E8C\u4E2A\u53C2\u6570\u76F4\u63A5\u8FD4\u56DE\u539F\u6570\u636E\uFF0C\u4E0D\u5728\u9700\u8981\u901A\u8FC7 ",["code","option.props.children"]," \u6765\u8FDB\u884C\u5339\u914D\u3002"]],["li",["p","Tree\u3001TreeSelect \u540C\u65F6\u6307\u5B9A ",["code","title"]," \u548C ",["code","label"]," \u7684\u65F6\u5019\uFF0C\u4F1A\u9009\u62E9\u663E\u793A ",["code","label"],"\u3002\u4E3A\u4E86 ",["code","labelInValue"]," \u884C\u4E3A\u4E00\u81F4\u8FDB\u884C\u4E86\u8BE5\u8C03\u6574\u3002",["a",{title:null,href:"https://codesandbox.io/s/keen-curran-d3qnp"},"\u65B0\u884C\u4E3A"],"\uFF08\u5728\u7B2C\u4E00\u4E2A\u8282\u70B9\u5C55\u793A 'label'\uFF09\uFF0C",["a",{title:null,href:"https://codesandbox.io/s/muddy-darkness-57lb3"},"\u65E7\u884C\u4E3A"],"\uFF08\u5728\u7B2C\u4E00\u4E2A\u8282\u70B9\u5C55\u793A 'title'\uFF09\u3002"]],["li",["p","Tree \u4F20\u5165\u5185\u5BB9\u91C7\u7528 ",["code","treeData"]," \u5C5E\u6027\uFF0C\u6765\u4EE3\u66FF ",["code","TreeNode"]," \u65B9\u5F0F\uFF0CTreeNode \u4F9D\u7136\u53EF\u7528\uFF0C\u4F46\u662F\u4F1A\u5728\u63A7\u5236\u53F0\u629B\u51FA\u8B66\u544A\u3002"]]]],["li",["p","Grid \u7EC4\u4EF6\u4F7F\u7528 flex \u5E03\u5C40\u3002"]],["li",["p","Button \u7684 ",["code","danger"]," \u73B0\u5728\u4F5C\u4E3A\u4E00\u4E2A\u5C5E\u6027\u800C\u4E0D\u662F\u6309\u94AE\u7C7B\u578B\u3002"]],["li",["p","Input\u3001Select \u7684 ",["code","value"]," \u4E3A ",["code","undefined"]," \u65F6\u6539\u4E3A\u975E\u53D7\u63A7\u72B6\u6001\u3002"]],["li",["p","Table \u91CD\u5199"],["ul",["li",["p","\u5728\u6CA1\u6709 ",["code","columns"]," \u65F6\u4ECD\u7136\u4F1A\u4FDD\u7559\u4E00\u5217\u3002"]],["li",["p","\u5D4C\u5957 ",["code","dataIndex"]," \u652F\u6301\u4ECE ",["code","'xxx.yyy'"]," \u6539\u6210 ",["code","['xxx', 'yyy']"],"\u3002"]]]],["li",["p","Pagination \u81EA ",["code","4.1.0"]," \u8D77\u5927\u4E8E 50 \u6761\u6570\u636E\u9ED8\u8BA4\u4F1A\u5C55\u793A ",["code","pageSize"]," \u5207\u6362\u5668\uFF0C\u8FD9\u6761\u89C4\u5219\u540C\u6837\u4F1A\u8FD0\u7528\u4E8E Table \u4E0A\u3002"]],["li",["p","Tabs \u91CD\u5199\uFF08",["a",{title:null,href:"https://github.com/ant-design/ant-design/pull/24552"},"4.3.0"],"\uFF09"],["ul",["li",["p","Dom \u7ED3\u6784\u53D8\u5316\uFF0C\u5982\u6709\u8986\u76D6\u6837\u5F0F\u9700\u8981\u4ED4\u7EC6\u68C0\u67E5\u3002"]],["li",["p","\u6A2A\u5411\u6EDA\u52A8\u4EA4\u4E92\u53D8\u5316\uFF0C",["code","onPrevClick"]," \u548C ",["code","onNextClick"]," \u4E0D\u518D\u5DE5\u4F5C\u3002"]]]]],["pre",{lang:"diff",highlighted:`<span class="token deleted">&lt;Table</span>
  columns={[
    {
      title: 'Age',
<span class="token deleted">-     dataIndex: 'user.age',</span>
<span class="token inserted">+     dataIndex: ['user', 'age'],</span>
    },
  ]}
/>`},["code",`<Table
  columns={[
    {
      title: 'Age',
-     dataIndex: 'user.age',
+     dataIndex: ['user', 'age'],
    },
  ]}
/>`]],["h2","\u5F00\u59CB\u5347\u7EA7"],["p","\u4F60\u53EF\u4EE5\u624B\u52A8\u5BF9\u7167\u4E0A\u9762\u7684\u5217\u8868\u9010\u6761\u68C0\u67E5\u4EE3\u7801\u8FDB\u884C\u4FEE\u6539\uFF0C\u53E6\u5916\uFF0C\u6211\u4EEC\u4E5F\u63D0\u4F9B\u4E86\u4E00\u4E2A codemod cli \u5DE5\u5177 ",["a",{title:null,href:"https://github.com/ant-design/codemod-v4"},"@ant-design/codemod-v4"]," \u4EE5\u5E2E\u52A9\u4F60\u5FEB\u901F\u5347\u7EA7\u5230 v4 \u7248\u672C\u3002"],["p","\u5728\u8FD0\u884C codemod cli \u524D\uFF0C\u8BF7\u5148\u63D0\u4EA4\u4F60\u7684\u672C\u5730\u4EE3\u7801\u4FEE\u6539\u3002"],["pre",{lang:"shell",highlighted:`# \u901A\u8FC7 npx \u76F4\u63A5\u8FD0\u884C
npx <span class="token operator">-</span>p <span class="token variable">@ant</span><span class="token operator">-</span>design<span class="token operator">/</span>codemod<span class="token operator">-</span>v4 antd4<span class="token operator">-</span>codemod src

# \u6216\u8005\u5168\u5C40\u5B89\u88C5
# \u4F7F\u7528 npm
npm i <span class="token operator">-</span>g <span class="token variable">@ant</span><span class="token operator">-</span>design<span class="token operator">/</span>codemod<span class="token operator">-</span>v4
# \u6216\u8005\u4F7F\u7528 yarn
yarn <span class="token keyword">global</span> add <span class="token variable">@ant</span><span class="token operator">-</span>design<span class="token operator">/</span>codemod<span class="token operator">-</span>v4

# \u8FD0\u884C
antd4<span class="token operator">-</span>codemod src`},["code",`# \u901A\u8FC7 npx \u76F4\u63A5\u8FD0\u884C
npx -p @ant-design/codemod-v4 antd4-codemod src

# \u6216\u8005\u5168\u5C40\u5B89\u88C5
# \u4F7F\u7528 npm
npm i -g @ant-design/codemod-v4
# \u6216\u8005\u4F7F\u7528 yarn
yarn global add @ant-design/codemod-v4

# \u8FD0\u884C
antd4-codemod src`]],["p",["img",{src:"https://gw.alipayobjects.com/mdn/rms_08e378/afts/img/A*QdcbQoLC-cQAAAAAAAAAAABkARQnAQ",alt:"codemod running",width:"720"}]],["p","\u5BF9\u4E8E\u65E0\u6CD5\u81EA\u52A8\u4FEE\u6539\u7684\u90E8\u5206\uFF0Ccodemod \u4F1A\u5728\u547D\u4EE4\u884C\u8FDB\u884C\u63D0\u793A\uFF0C\u5EFA\u8BAE\u6309\u63D0\u793A\u624B\u52A8\u4FEE\u6539\u3002\u4FEE\u6539\u540E\u53EF\u4EE5\u53CD\u590D\u8FD0\u884C\u4E0A\u8FF0\u547D\u4EE4\u8FDB\u884C\u68C0\u67E5\u3002"],["p",["img",{src:"https://gw.alipayobjects.com/mdn/rms_08e378/afts/img/A*KQwWSrPirlUAAAAAAAAAAABkARQnAQ",alt:"contains an invalid icon",width:"720"}]],["blockquote",["p","\u6CE8\u610F codemod \u4E0D\u80FD\u6DB5\u76D6\u6240\u6709\u573A\u666F\uFF0C\u5EFA\u8BAE\u8FD8\u662F\u8981\u6309\u4E0D\u517C\u5BB9\u7684\u53D8\u5316\u9010\u6761\u6392\u67E5\u3002"]],["h3","\u8FC1\u79FB\u5DE5\u5177\u4FEE\u6539\u8BE6\u60C5"],["p",["code","@ant-design/codemod-v4"]," \u4F1A\u5E2E\u4F60\u8FC1\u79FB\u5230 antd v4, \u5E9F\u5F03\u7684\u7EC4\u4EF6\u5219\u901A\u8FC7 ",["code","@ant-design/compatible"]," \u4FDD\u6301\u8FD0\u884C, \u4E00\u822C\u6765\u8BF4\u4F60\u65E0\u9700\u624B\u52A8\u8FC1\u79FB\u3002\u4E0B\u65B9\u5185\u5BB9\u8BE6\u7EC6\u4ECB\u7ECD\u4E86\u6574\u4F53\u7684\u8FC1\u79FB\u548C\u53D8\u5316\uFF0C\u4F60\u4E5F\u53EF\u4EE5\u53C2\u7167\u53D8\u52A8\u624B\u52A8\u4FEE\u6539\u3002"],["h4","\u5C06\u5DF2\u5E9F\u5F03\u7684 ",["code","Form"]," \u548C ",["code","Mention"]," \u7EC4\u4EF6\u901A\u8FC7 ",["code","@ant-design/compatible"]," \u5305\u5F15\u5165"],["pre",{lang:"diff",highlighted:`<span class="token deleted">- import { Form, Input, Button, Mention } from 'antd';</span>
<span class="token inserted">+ import { Form, Mention } from '@ant-design/compatible';</span>
<span class="token inserted">+ import '@ant-design/compatible/assets/index.css';</span>
<span class="token inserted">+ import { Input, Button } from 'antd';</span>

  ReactDOM.render( (
    &lt;div>
      &lt;Form>
        {getFieldDecorator('username')(&lt;Input />)}
        &lt;Button>Submit&lt;/Button>
      &lt;/Form>
      &lt;Mention
        style={{ width: '100%' }}
        onChange={onChange}
        defaultValue={toContentState('@afc163')}
        defaultSuggestions={['afc163', 'benjycui']}
        onSelect={onSelect}
      />
    &lt;/div>
  );`},["code",`- import { Form, Input, Button, Mention } from 'antd';
+ import { Form, Mention } from '@ant-design/compatible';
+ import '@ant-design/compatible/assets/index.css';
+ import { Input, Button } from 'antd';

  ReactDOM.render( (
    <div>
      <Form>
        {getFieldDecorator('username')(<Input />)}
        <Button>Submit</Button>
      </Form>
      <Mention
        style={{ width: '100%' }}
        onChange={onChange}
        defaultValue={toContentState('@afc163')}
        defaultSuggestions={['afc163', 'benjycui']}
        onSelect={onSelect}
      />
    </div>
  );`]],["blockquote",["p",["strong","\u6CE8\u610F\uFF1A"],"\u4ECE ",["code","@ant-design/compatible"]," \u5F15\u5165\u7684\u8001\u7248\u672C Form \u7EC4\u4EF6\uFF0C\u6837\u5F0F\u7C7B\u540D\u4F1A\u4ECE ",["code",".ant-form"]," \u53D8\u6210 ",["code",".ant-legacy-form"],"\uFF0C\u5982\u679C\u4F60\u5BF9\u5176\u8FDB\u884C\u4E86\u6837\u5F0F\u8986\u76D6\uFF0C\u4E5F\u9700\u8981\u76F8\u5E94\u4FEE\u6539\u3002"]],["h4","\u7528\u65B0\u7684 ",["code","@ant-design/icons"]," \u66FF\u6362\u5B57\u7B26\u4E32\u7C7B\u578B\u7684 ",["code","icon"]," \u5C5E\u6027\u503C"],["pre",{lang:"diff",highlighted:`  import { Avatar, Button, Result } from 'antd';
<span class="token inserted">+ import { QuestionOutlined, UserOutlined } from '@ant-design/icons';</span>

  ReactDOM.render(
    &lt;div>
<span class="token deleted">-     &lt;Button type="primary" shape="circle" icon="search" /></span>
<span class="token inserted">+     &lt;Button type="primary" shape="circle" icon={SearchOutlined} /></span>
<span class="token deleted">-     &lt;Avatar shape="square" icon="user" /></span>
<span class="token inserted">+     &lt;Avatar shape="square" icon={UserOutlined} /></span>
      &lt;Result
<span class="token deleted">-       icon="question"</span>
<span class="token inserted">+       icon={&lt;QuestionOutlined />}</span>
        title="Great, we have done all the operations!"
        extra={&lt;Button type="primary">Next&lt;/Button>}
      />
    &lt;/div>,
    mountNode,
  );`},["code",`  import { Avatar, Button, Result } from 'antd';
+ import { QuestionOutlined, UserOutlined } from '@ant-design/icons';

  ReactDOM.render(
    <div>
-     <Button type="primary" shape="circle" icon="search" />
+     <Button type="primary" shape="circle" icon={SearchOutlined} />
-     <Avatar shape="square" icon="user" />
+     <Avatar shape="square" icon={UserOutlined} />
      <Result
-       icon="question"
+       icon={<QuestionOutlined />}
        title="Great, we have done all the operations!"
        extra={<Button type="primary">Next</Button>}
      />
    </div>,
    mountNode,
  );`]],["h4","\u5C06 v3 Icon \u7EC4\u4EF6\u8F6C\u6362\u6210 ",["code","@ant-design/icons"]," \u4E2D\u5F15\u5165"],["pre",{lang:"diff",highlighted:`<span class="token deleted">- import { Icon, Input } from 'antd';</span>
<span class="token inserted">+ import { Input } from 'antd';</span>
<span class="token inserted">+ import Icon, { CodeFilled, SmileOutlined, SmileTwoTone } from '@ant-design/icons';</span>

  const HeartSvg = () => (
    &lt;svg width="1em" height="1em" fill="currentColor" viewBox="0 0 1024 1024">
      &lt;path d="M923 plapla..." />
    &lt;/svg>
  );

  const HeartIcon = props => &lt;Icon component={HeartSvg} {...props} />;

  ReactDOM.render(
    &lt;div>
<span class="token deleted">-     &lt;Icon type="code" theme="filled" /></span>
<span class="token inserted">+     &lt;CodeFilled /></span>
<span class="token deleted">-     &lt;Icon type="smile" theme="twoTone" twoToneColor="#eb2f96" /></span>
<span class="token inserted">+     &lt;SmileTwoTone twoToneColor="#eb2f96" /></span>
<span class="token deleted">-     &lt;Icon type="code" theme={props.fill ? 'filled' : 'outlined'} /></span>
<span class="token inserted">+     &lt;LegacyIcon type="code" theme={props.fill ? 'filled' : 'outlined'} /></span>
      &lt;HeartIcon />
      &lt;Icon viewBox="0 0 24 24">
        &lt;title>Cool Home&lt;/title>
        &lt;path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" />
      &lt;/Icon>
      &lt;Input suffix={&lt;SmileOutlined />} />
    &lt;/div>,
    mountNode,
  );`},["code",`- import { Icon, Input } from 'antd';
+ import { Input } from 'antd';
+ import Icon, { CodeFilled, SmileOutlined, SmileTwoTone } from '@ant-design/icons';

  const HeartSvg = () => (
    <svg width="1em" height="1em" fill="currentColor" viewBox="0 0 1024 1024">
      <path d="M923 plapla..." />
    </svg>
  );

  const HeartIcon = props => <Icon component={HeartSvg} {...props} />;

  ReactDOM.render(
    <div>
-     <Icon type="code" theme="filled" />
+     <CodeFilled />
-     <Icon type="smile" theme="twoTone" twoToneColor="#eb2f96" />
+     <SmileTwoTone twoToneColor="#eb2f96" />
-     <Icon type="code" theme={props.fill ? 'filled' : 'outlined'} />
+     <LegacyIcon type="code" theme={props.fill ? 'filled' : 'outlined'} />
      <HeartIcon />
      <Icon viewBox="0 0 24 24">
        <title>Cool Home</title>
        <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" />
      </Icon>
      <Input suffix={<SmileOutlined />} />
    </div>,
    mountNode,
  );`]],["h4","\u5C06 v3 LocaleProvider \u7EC4\u4EF6\u8F6C\u6362\u6210 v4 ConfigProvider \u7EC4\u4EF6"],["pre",{lang:"diff",highlighted:`<span class="token deleted">- import { LocaleProvider } from 'antd';</span>
<span class="token inserted">+ import { ConfigProvider } from 'antd';</span>

  ReactDOM.render(
<span class="token deleted">-   &lt;LocaleProvider {...yourConfig}></span>
<span class="token inserted">+   &lt;ConfigProvider {...yourConfig}></span>
      &lt;Main />
<span class="token deleted">-   &lt;/LocaleProvider></span>
<span class="token inserted">+   &lt;/ConfigProvider></span>
    mountNode,
  );`},["code",`- import { LocaleProvider } from 'antd';
+ import { ConfigProvider } from 'antd';

  ReactDOM.render(
-   <LocaleProvider {...yourConfig}>
+   <ConfigProvider {...yourConfig}>
      <Main />
-   </LocaleProvider>
+   </ConfigProvider>
    mountNode,
  );`]],["h4","\u5C06 ",["code","Modal.method()"]," \u4E2D\u5B57\u7B26\u4E32 icon \u5C5E\u6027\u7684\u8C03\u7528\u8F6C\u6362\u6210\u4ECE ",["code","@ant-design/icons"]," \u4E2D\u5F15\u5165"],["pre",{lang:"diff",highlighted:`  import { Modal } from 'antd';
<span class="token inserted">+ import { AntDesignOutlined } from '@ant-design/icons';</span>

  Modal.confirm({
<span class="token deleted">-  icon: 'ant-design',</span>
<span class="token inserted">+  icon: &lt;AntDesignOutlined />,</span>
   title: 'Do you Want to delete these items?',
   content: 'Some descriptions',
   onOk() {
     console.log('OK');
   },
   onCancel() {
     console.log('Cancel');
   },
 });`},["code",`  import { Modal } from 'antd';
+ import { AntDesignOutlined } from '@ant-design/icons';

  Modal.confirm({
-  icon: 'ant-design',
+  icon: <AntDesignOutlined />,
   title: 'Do you Want to delete these items?',
   content: 'Some descriptions',
   onOk() {
     console.log('OK');
   },
   onCancel() {
     console.log('Cancel');
   },
 });`]],["h2","\u9047\u5230\u95EE\u9898"],["p","v4 \u505A\u4E86\u975E\u5E38\u591A\u7684\u7EC6\u8282\u6539\u8FDB\u548C\u91CD\u6784\uFF0C\u6211\u4EEC\u5C3D\u53EF\u80FD\u6536\u96C6\u4E86\u5DF2\u77E5\u7684\u6240\u6709\u4E0D\u517C\u5BB9\u53D8\u5316\u548C\u76F8\u5173\u5F71\u54CD\uFF0C\u4F46\u662F\u6709\u53EF\u80FD\u8FD8\u662F\u6709\u4E00\u4E9B\u573A\u666F\u6211\u4EEC\u6CA1\u6709\u8003\u8651\u5230\u3002\u5982\u679C\u4F60\u5728\u5347\u7EA7\u8FC7\u7A0B\u4E2D\u9047\u5230\u4E86\u95EE\u9898\uFF0C\u8BF7\u5230 ",["a",{title:null,href:"http://new-issue.ant.design/"},"GitHub issues"]," \u548C ",["a",{title:null,href:"https://github.com/ant-design/codemod-v4/issues"},"codemod Issues"]," \u8FDB\u884C\u53CD\u9988\u3002\u6211\u4EEC\u4F1A\u5C3D\u5FEB\u54CD\u5E94\u548C\u76F8\u5E94\u6539\u8FDB\u8FD9\u7BC7\u6587\u6863\u3002"]],meta:{order:8,title:"\u4ECE v3 \u5230 v4",filename:"docs/react/migration-v4.zh-CN.md"},toc:["ul",["li",["a",{className:"bisheng-toc-h2",href:"#\u5347\u7EA7\u51C6\u5907",title:"\u5347\u7EA7\u51C6\u5907"},"\u5347\u7EA7\u51C6\u5907"]],["li",["a",{className:"bisheng-toc-h2",href:"#4.0-\u6709\u54EA\u4E9B\u4E0D\u517C\u5BB9\u7684\u53D8\u5316",title:"4.0 \u6709\u54EA\u4E9B\u4E0D\u517C\u5BB9\u7684\u53D8\u5316"},"4.0 \u6709\u54EA\u4E9B\u4E0D\u517C\u5BB9\u7684\u53D8\u5316"]],["li",["a",{className:"bisheng-toc-h2",href:"#\u5F00\u59CB\u5347\u7EA7",title:"\u5F00\u59CB\u5347\u7EA7"},"\u5F00\u59CB\u5347\u7EA7"]],["li",["a",{className:"bisheng-toc-h2",href:"#\u9047\u5230\u95EE\u9898",title:"\u9047\u5230\u95EE\u9898"},"\u9047\u5230\u95EE\u9898"]]]}}}]);
